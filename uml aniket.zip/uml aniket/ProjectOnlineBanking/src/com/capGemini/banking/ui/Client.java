package com.capGemini.banking.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capGemini.banking.dao.BankingDao;
import com.capGemini.banking.dao.BankingDaoImpl;
import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;

public class Client {

	public static void main(String[] args) throws BankingException {
		
		final Logger mylogger=Logger.getLogger(Client.class);
		mylogger.info("Application Started...");
		BankingDao dao= new BankingDaoImpl();
		//boolean check=false;
		int choice=0;
		printDetail();
		Scanner sc = new Scanner(System.in);
		choice = sc.nextInt();
		switch(choice){
		
		case 1:{
			System.out.println("Userid::");
			String id=sc.next();
			System.out.println("Password::");
			String pass =sc.next();
			boolean check=isValid(id, pass);
			if(check){
				System.out.println("Login Successfull");
				System.out.println("Account Holder Name::");
				String name=sc.next();
				System.out.println("Address");
				String address=sc.next();
				System.out.println("Enter PAN Card Details::");
				String pan=sc.next();
				System.out.println("Enter MobileNo::");
				String mobile=sc.next();
				System.out.println("Enter AccountType::");
				String accType=sc.next();
				System.out.println("Enter Account balance");
				double aBal=sc.nextDouble();
				CustomerDto cust=new CustomerDto();
				
				
				cust.setCustomer_name(name);
				cust.setAddress(address);
				cust.setPancard(pan);
				cust.setMobileNo(mobile);
				AccountDto acc= new AccountDto();
				acc.setAccount_Type(accType);
				acc.setAccount_Balance(aBal);
				UserDto userDto= dao.addCustomerDetails(cust, acc);
				long accountID=userDto.getAccount_ID();
				int userID=userDto.getUser_id();
				String password=userDto.getLogin_password();
				System.out.println("AccountID= "+accountID+" UserId="+userID+" password= "+password);
			}
			}
		}
		
	

	}
	public static void printDetail() {
		System.out.println("Choice an Operation");
		System.out.println("1. Admin");
		System.out.println("2. User");
		System.out.println("0. Exit");
		System.out.println("************************");
		System.out.println("please enter your choice=");
		System.out.println("************************************");
	}
	
	public static boolean isValid(String id, String pass) {
		
		if((id.equals("101"))&&(pass.equals("admin"))){
			return true;
		}
		return false;
		
	}

}
