package com.capGemini.banking.dto;

import java.sql.Date;

public class Fund_Transfer {
	private int fundTransferId;
	private long accountId;
	private long payeeAccId;
	private Date dateOfTransfer;
	private double transfer_amount;
	public Fund_Transfer() {
		// TODO Auto-generated constructor stub
	}
	public int getFundTransferId() {
		return fundTransferId;
	}
	public void setFundTransferId(int fundTransferId) {
		this.fundTransferId = fundTransferId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public long getPayeeAccId() {
		return payeeAccId;
	}
	public void setPayeeAccId(long payeeAccId) {
		this.payeeAccId = payeeAccId;
	}
	public Date getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(Date dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public double getTransfer_amount() {
		return transfer_amount;
	}
	public void setTransfer_amount(double transfer_amount) {
		this.transfer_amount = transfer_amount;
	}
	
	
}
