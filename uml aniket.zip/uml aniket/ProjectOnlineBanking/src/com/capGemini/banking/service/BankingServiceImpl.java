package com.capGemini.banking.service;

import java.util.List;

import com.capGemini.banking.dao.BankingDao;
import com.capGemini.banking.dao.BankingDao1;
import com.capGemini.banking.dao.BankingDao1Impl;
import com.capGemini.banking.dao.BankingDaoImpl;
import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.Fund_Transfer;
import com.capGemini.banking.dto.PayeeTable;
import com.capGemini.banking.dto.ServiceTracker;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;

public class BankingServiceImpl implements BankingService {
BankingDao bankDao;
BankingDao1 bankDao1;
	public BankingServiceImpl() {
		bankDao=new BankingDaoImpl();
		bankDao1=new BankingDao1Impl();
	}
	@Override
	public int addCustDetails(CustomerDto cust, AccountDto acc)
			throws BankingException {
		return bankDao.addCustDetails(cust,acc);
	}
	@Override
	public UserDto getUserDto(long accId) throws BankingException {
		
		return bankDao.getUserDto(accId);
	}

	@Override
	public CustomerDto getCustomerDetails(long accId) throws BankingException {
		
		return bankDao.getCustomerDetails(accId);
	}

	@Override
	public boolean updateDetails(CustomerDto customer) throws BankingException {
		// TODO Auto-generated method stub
		return bankDao.updateDetails(customer);
	}

	@Override
	public long validateUserId(int userId, String password)
			throws BankingException {
		// TODO Auto-generated method stub
		return bankDao.validateUserId(userId, password);
	}

	@Override
	public int registerService(ServiceTracker serviceTracker)
			throws BankingException {

		serviceTracker.setServiceStatus("Requested");
		return bankDao1.registerService(serviceTracker);
	}

	@Override
	public boolean registerPayee(PayeeTable payee) throws BankingException {
		// TODO Auto-generated method stub
		return bankDao1.registerPayee(payee);
	}

	@Override
	public List<String> getPayeeIdName(long accountId) throws BankingException {
		// TODO Auto-generated method stub
		return bankDao1.getPayeeIdName(accountId);
	}
	@Override
	public int makeFundTransfer(Fund_Transfer fund) throws BankingException {
		// TODO Auto-generated method stub
		return bankDao1.makeFundTransfer(fund);
	}
	@Override
	public List<Long> getAllAccId(long accId) throws BankingException {
		// TODO Auto-generated method stub
		return bankDao1.getAllAccId(accId);
	}
	@Override
	public int isAuthenticated(int id, String password) throws BankingException {
		// TODO Auto-generated method stub
		return bankDao.isValidUser(id, password);
	}
	@Override
	public String ResetPassword(int userid, String oldPass, String newPass)
			throws BankingException {
		// TODO Auto-generated method stub
		return bankDao1.ResetPassword(userid, oldPass, newPass);
	}

}
